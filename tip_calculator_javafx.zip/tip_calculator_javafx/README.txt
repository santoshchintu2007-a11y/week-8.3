TIP CALCULATOR (JavaFX + FXML)

Requirements:
- JDK 17 or newer
- Maven installed

Run:
1. Extract the ZIP file.
2. Open a terminal in the extracted tip_calculator_javafx folder.
3. Run: mvn clean javafx:run

Files:
- TipCalculatorApp.java: launches the JavaFX application.
- TipCalculatorController.java: validates inputs, calculates tip, and resets fields.
- tip_calculator.fxml: user interface layout.
- pom.xml: Maven configuration.

Example:
Bill Amount = 50.00
Tip Percentage = 15
Result = Tip Amount: $7.50
